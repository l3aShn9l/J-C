package com.example.healthcare.classes;

public class Activity {
    public String activity = "";
    public Double activityDuration = 0.;
    public Integer spentCalories = 0;
    public Activity(String activity, Double activityDuration, Integer spentCalories){
        this.activity = activity;
        this.activityDuration = activityDuration;
        this.spentCalories = spentCalories;
    }
}
