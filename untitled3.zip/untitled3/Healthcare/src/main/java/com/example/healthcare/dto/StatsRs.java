package com.example.healthcare.dto;

import com.example.healthcare.classes.Stats;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class StatsRs {
    private Stats stats;
    private Integer receivedCalories;
    private Integer spentCalories;
    private Integer balance;
}

