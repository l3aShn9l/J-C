package com.example.healthcare.dto;

import lombok.Data;


import java.time.LocalDateTime;

@Data
public class SessionRs {
    private Long id;

    private String username;

    private String email;

    private String password;

    private String role;

    private LocalDateTime created_at;

    private LocalDateTime updated_at;
}
