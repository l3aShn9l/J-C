package com.example.healthcare.service;

import com.example.healthcare.dto.UserRq;
import com.example.healthcare.entity.User;
import com.example.healthcare.mapper.UserMapper;
import com.example.healthcare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public void saveUser(UserRq userRq){
        User dto = UserMapper.INSTANCE.toModel(userRq);
        userRepository.saveAndFlush(dto);
    }
    @Bean
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }
}
