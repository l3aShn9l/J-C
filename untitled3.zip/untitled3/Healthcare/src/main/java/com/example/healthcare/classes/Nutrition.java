package com.example.healthcare.classes;

public class Nutrition {
    public String dish = "";
    public Integer portion = 0;
    public Integer receivedCalories = 0;
    public Nutrition(String dish, Integer portion, Integer receivedCalories){
        this.dish = dish;
        this.portion = portion;
        this.receivedCalories = receivedCalories;
    }
}
