package com.example.healthcare.controller;

import com.example.healthcare.classes.Activity;
import com.example.healthcare.classes.Nutrition;
import com.example.healthcare.classes.Stats;
import com.example.healthcare.dto.*;
import com.example.healthcare.entity.User;
import com.example.healthcare.entity.Session;
import com.example.healthcare.repository.SessionRepository;
import com.example.healthcare.repository.UserRepository;
import com.example.healthcare.security.JwtUtils;
import com.example.healthcare.service.HealthcareService;
import com.example.healthcare.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;


@RestController
@RequestMapping("")
@RequiredArgsConstructor
public class HealthcareController {
    private final UserService userService;
    private final UserRepository userRepository;
    private final SessionRepository sessionRepository;
    private final JwtUtils jwtUtils;

    @Autowired
    private PasswordEncoder passwordEncoder;
    private Stats stats = new Stats();

    @PostMapping("/nutrition")
    public ResponseEntity<String> nutririon(@Valid @RequestBody NutritionRq nutritionRq) {
        Nutrition nutrition = new Nutrition(nutritionRq.getDish(), nutritionRq.getPortion(), nutritionRq.getPortion());
        stats.nutritions.add(nutrition);
        return ResponseEntity.ok("Updated successfully");
    }
    @PostMapping("/activity")
    public ResponseEntity<String> activity(@Valid @RequestBody ActivityRq activityRq) {
        Activity activity = new Activity(activityRq.getActivity(), activityRq.getActivityDuration(), activityRq.getSpentCalories());
        stats.activities.add(activity);
        return ResponseEntity.ok("Updated successfully");
    }
    @PostMapping("/sleep")
    public ResponseEntity<String> sleep(@Valid @RequestBody SleepRq sleepRq) {
        stats.sleepDuration = sleepRq.getSleepDuration();
        return ResponseEntity.ok("Updated successfully");
    }

    @GetMapping("/stats")
    public ResponseEntity<?> stats() {
        return ResponseEntity.ok(stats);
    }

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@Valid @RequestBody UserRq user) {
        if (userRepository.findByEmail(user.getEmail()) != null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Email already exists");
        }

        if (userRepository.findByUsername(user.getUsername()) != null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Username already exists");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userService.saveUser(user);
        return ResponseEntity.ok("User registered successfully");
    }
    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody UserCredentials credentials) {
        User user = userRepository.findByEmail(credentials.getEmail());
        if (user == null || !passwordEncoder.matches(credentials.getPassword(), user.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
        // Генерация JWT токена и сохранение сессии в базу данных
        String sessionToken = jwtUtils.generateJwtToken(user.getEmail());
        Session session = new Session();
        session.setUserId(user);
        session.setSessionToken(sessionToken);
        session.setExpiresAt(LocalDateTime.now().plusHours(1)); // Настройте срок действия токена
        sessionRepository.save(session);

        return ResponseEntity.ok(sessionToken);
    }
}