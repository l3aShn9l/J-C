package com.example.healthcare.mapper;


import com.example.healthcare.dto.UserRq;
import com.example.healthcare.dto.UserRs;
import com.example.healthcare.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface UserMapper {
    UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);


    User toModel(UserRq userRq);

    UserRs toDTO(User user);
}