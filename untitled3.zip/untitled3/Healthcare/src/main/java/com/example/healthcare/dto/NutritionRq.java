package com.example.healthcare.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NutritionRq {
    @NotBlank(message = "Field 'dish' is empty")
    private String dish;
    @NotBlank(message = "Field 'portion' is empty")
    private Integer portion;
    @NotBlank(message = "Field 'receivedCalories' is empty")
    private Integer receivedCalories;
}
