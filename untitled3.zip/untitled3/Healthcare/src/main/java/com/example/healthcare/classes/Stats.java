package com.example.healthcare.classes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Stats {
    public List<Activity> activities = new ArrayList<>(Collections.emptyList());
    public List<Nutrition> nutritions = new ArrayList<>(Collections.emptyList());
    public Double sleepDuration = 0.;

}
